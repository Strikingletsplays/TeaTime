﻿using UnityEngine;
using System.Collections;

public class RecursiveBundle {
    public int Index { get; set; }
    public RecursiveInstantiator Parent { get; set; }
}
